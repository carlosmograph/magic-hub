@echo off
rem Duplo clique para instalar o Magic Hub no After Effects e no Premiere.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar-windows.ps1"
pause
