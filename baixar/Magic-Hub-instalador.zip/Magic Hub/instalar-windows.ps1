# Magic Hub - instalador para Windows
# Faz tres coisas, todas so no seu usuario (sem administrador):
#   1. Extrai o MagicHub.zxp em %APPDATA%\Adobe\CEP\extensions\com.crmo.hub
#   2. Liga o PlayerDebugMode do CEP (HKCU\Software\Adobe\CSXS.9 a .14), para o
#      After/Premiere abrirem paineis que nao vieram da Adobe Exchange
#   3. Apaga a copia antiga do painel no cache do CEP
# Para desinstalar: apague a pasta do passo 1.

$ErrorActionPreference = "Stop"
$pacote = Join-Path $PSScriptRoot "MagicHub.zxp"
$destino = Join-Path $env:APPDATA "Adobe\CEP\extensions\com.crmo.hub"

Write-Host ""
Write-Host "  MAGIC HUB" -ForegroundColor Magenta
Write-Host "  Instala o painel no After Effects e no Premiere (2022 ou mais novo)."
Write-Host ""
Write-Host "  Pasta:    $destino"
Write-Host "  Registro: PlayerDebugMode = 1 em HKCU\Software\Adobe\CSXS.9..14"
Write-Host ""
$ok = Read-Host "  Feche o After Effects e o Premiere. Continuar? (S/N)"
if ($ok -notmatch '^[sSyY]') { Write-Host "  Nada foi alterado."; exit 0 }

try {
    if (-not (Test-Path $pacote)) { throw "MagicHub.zxp nao esta ao lado deste instalador. Extraia o .zip inteiro antes." }
    if (Get-Process -Name "AfterFX", "Adobe Premiere Pro" -ErrorAction SilentlyContinue) {
        Write-Host "  O After Effects ou o Premiere ainda esta aberto - o painel so aparece depois de reabrir." -ForegroundColor Yellow
    }

    # extrai ao lado e so entao troca: se algo falhar, a versao anterior continua la
    $novo = "$destino.crmo-novo"
    if (Test-Path $novo) { Remove-Item $novo -Recurse -Force }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [System.IO.Compression.ZipFile]::ExtractToDirectory($pacote, $novo)
    if (Test-Path $destino) { Remove-Item $destino -Recurse -Force }
    Move-Item $novo $destino
    Get-ChildItem $destino -Recurse -File | Unblock-File -ErrorAction SilentlyContinue

    foreach ($v in 9..14) {
        $chave = "HKCU:\Software\Adobe\CSXS.$v"
        if (-not (Test-Path $chave)) { New-Item -Path $chave -Force | Out-Null }
        Set-ItemProperty -Path $chave -Name PlayerDebugMode -Value "1" -Type String
    }

    $cache = Join-Path $env:TEMP "cep_cache"
    if (Test-Path $cache) {
        Get-ChildItem $cache -Directory | Where-Object { $_.Name -like "*_com.crmo.hub.panel" } |
            Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    }
} catch {
    Write-Host ""
    Write-Host "  Nao deu para instalar: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "  Feche o After Effects e o Premiere e rode de novo."
    Write-Host ""
    exit 1
}

Write-Host ""
Write-Host "  Pronto." -ForegroundColor Green
Write-Host "  Abra o After Effects ou o Premiere: Janela > Extensoes > Magic Hub"
Write-Host "  (Window > Extensions > Magic Hub) e entre com a sua conta."
Write-Host ""
