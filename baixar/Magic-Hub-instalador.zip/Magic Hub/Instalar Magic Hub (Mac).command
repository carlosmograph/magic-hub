#!/bin/bash
# Magic Hub - instalador para macOS. Duplo clique (se o Mac bloquear: botão direito > Abrir).
# Só mexe no seu usuário: extrai o painel em ~/Library/Application Support/Adobe/CEP/extensions
# e liga o PlayerDebugMode do CEP. Para desinstalar, apague a pasta com.crmo.hub.
set -e
cd "$(dirname "$0")"
PACOTE="MagicHub.zxp"
DESTINO="$HOME/Library/Application Support/Adobe/CEP/extensions/com.crmo.hub"

echo ""
echo "  MAGIC HUB"
echo "  Instala o painel no After Effects e no Premiere (2022 ou mais novo)."
echo "  Pasta: $DESTINO"
echo ""
read -r -p "  Feche o After Effects e o Premiere. Continuar? (s/n) " OK
case "$OK" in [sSyY]*) ;; *) echo "  Nada foi alterado."; exit 0 ;; esac

if [ ! -f "$PACOTE" ]; then echo "  MagicHub.zxp não está ao lado deste instalador."; exit 1; fi

NOVO="$DESTINO.crmo-novo"
rm -rf "$NOVO"
mkdir -p "$NOVO"
unzip -q "$PACOTE" -d "$NOVO"
rm -rf "$DESTINO"
mv "$NOVO" "$DESTINO"
xattr -dr com.apple.quarantine "$DESTINO" 2>/dev/null || true

for v in 9 10 11 12 13 14; do defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1; done
rm -rf "$HOME/Library/Caches/CSXS/cep_cache/"*"_com.crmo.hub.panel" 2>/dev/null || true

echo ""
echo "  Pronto. Abra o After Effects ou o Premiere: Janela > Extensões > Magic Hub"
echo ""
